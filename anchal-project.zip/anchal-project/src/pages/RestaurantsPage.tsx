import React, { useState } from 'react';
import { Link } from 'react-router-dom';

interface Restaurant {
  id: string;
  name: string;
  image: string;
  cuisine: string;
  rating: number;
  deliveryTime: string;
  minOrder: number;
  deliveryFee: number;
}

const mockRestaurants: Restaurant[] = [
  {
    id: '1',
    name: 'Pizza Heaven',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500',
    cuisine: 'Italian',
    rating: 4.7,
    deliveryTime: '30-40 min',
    minOrder: 15,
    deliveryFee: 2.99,
  },
  {
    id: '2',
    name: 'Burger Palace',
    image: 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=500',
    cuisine: 'American',
    rating: 4.5,
    deliveryTime: '25-35 min',
    minOrder: 12,
    deliveryFee: 1.99,
  },
  {
    id: '3',
    name: 'Sushi Master',
    image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=500',
    cuisine: 'Japanese',
    rating: 4.8,
    deliveryTime: '35-45 min',
    minOrder: 20,
    deliveryFee: 3.99,
  },
  {
    id: '4',
    name: 'Spice Route',
    image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=500',
    cuisine: 'Indian',
    rating: 4.6,
    deliveryTime: '40-50 min',
    minOrder: 18,
    deliveryFee: 2.99,
  },
];

const cuisineTypes = ['All', 'Italian', 'American', 'Japanese', 'Indian', 'Chinese', 'Mexican'];

const RestaurantsPage: React.FC = () => {
  const [selectedCuisine, setSelectedCuisine] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredRestaurants = mockRestaurants.filter((restaurant) => {
    const matchesCuisine = selectedCuisine === 'All' || restaurant.cuisine === selectedCuisine;
    const matchesSearch = restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      restaurant.cuisine.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCuisine && matchesSearch;
  });

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Search and Filter Section */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Search restaurants or cuisines..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
            {cuisineTypes.map((cuisine) => (
              <button
                key={cuisine}
                className={`px-4 py-2 rounded-full whitespace-nowrap ${
                  selectedCuisine === cuisine
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                }`}
                onClick={() => setSelectedCuisine(cuisine)}
              >
                {cuisine}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Restaurants Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRestaurants.map((restaurant) => (
          <Link
            key={restaurant.id}
            to={`/restaurant/${restaurant.id}`}
            className="block bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
          >
            <div className="relative h-48">
              <img
                src={restaurant.image}
                alt={restaurant.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 bg-white px-2 py-1 rounded-full text-sm font-semibold">
                {restaurant.deliveryTime}
              </div>
            </div>
            <div className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-xl font-semibold">{restaurant.name}</h3>
                <div className="flex items-center bg-green-50 px-2 py-1 rounded">
                  <svg
                    className="w-4 h-4 text-yellow-400 mr-1"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                  <span>{restaurant.rating}</span>
                </div>
              </div>
              <p className="text-gray-600 mb-2">{restaurant.cuisine}</p>
              <div className="flex items-center justify-between text-sm text-gray-500">
                <span>Min. order ${restaurant.minOrder}</span>
                <span>Delivery ${restaurant.deliveryFee.toFixed(2)}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {filteredRestaurants.length === 0 && (
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">No restaurants found</h2>
          <p className="text-gray-600">
            Try adjusting your search or filters to find more restaurants.
          </p>
        </div>
      )}
    </div>
  );
};

export default RestaurantsPage; 