import React from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '../redux/store';

interface Order {
  id: string;
  date: string;
  restaurant: string;
  items: string[];
  total: number;
  status: 'delivered' | 'in-progress' | 'cancelled';
}

const mockOrders: Order[] = [
  {
    id: '1',
    date: '2024-03-23',
    restaurant: 'Pizza Heaven',
    items: ['Margherita Pizza x2', 'Garlic Bread'],
    total: 29.97,
    status: 'delivered',
  },
  {
    id: '2',
    date: '2024-03-22',
    restaurant: 'Burger Palace',
    items: ['Classic Burger', 'Fries', 'Coke'],
    total: 15.99,
    status: 'delivered',
  },
  {
    id: '3',
    date: '2024-03-24',
    restaurant: 'Sushi Master',
    items: ['California Roll', 'Miso Soup'],
    total: 22.50,
    status: 'in-progress',
  },
];

const ProfilePage: React.FC = () => {
  const { user } = useSelector((state: RootState) => state.auth);

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Please log in to view your profile</h1>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Profile Header */}
        <div className="bg-white shadow rounded-lg p-6 mb-6">
          <div className="flex items-center">
            <div className="h-20 w-20 rounded-full bg-indigo-600 flex items-center justify-center text-white text-2xl font-bold">
              {user.name.charAt(0)}
            </div>
            <div className="ml-6">
              <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
              <p className="text-gray-600">{user.email}</p>
            </div>
          </div>
        </div>

        {/* Order History */}
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-4">Order History</h2>
          <div className="space-y-4">
            {mockOrders.map((order) => (
              <div key={order.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-semibold">{order.restaurant}</h3>
                    <p className="text-sm text-gray-600">{order.date}</p>
                  </div>
                  <div className="flex items-center">
                    <span
                      className={`px-2 py-1 text-sm rounded ${
                        order.status === 'delivered'
                          ? 'bg-green-100 text-green-800'
                          : order.status === 'in-progress'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </span>
                  </div>
                </div>
                <div className="text-sm text-gray-600">
                  {order.items.map((item, index) => (
                    <div key={index}>{item}</div>
                  ))}
                </div>
                <div className="mt-2 text-right font-semibold">
                  Total: ${order.total.toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Settings Section */}
        <div className="bg-white shadow rounded-lg p-6 mt-6">
          <h2 className="text-xl font-semibold mb-4">Account Settings</h2>
          <div className="space-y-4">
            <button className="w-full text-left px-4 py-2 border rounded hover:bg-gray-50">
              Edit Profile
            </button>
            <button className="w-full text-left px-4 py-2 border rounded hover:bg-gray-50">
              Change Password
            </button>
            <button className="w-full text-left px-4 py-2 border rounded hover:bg-gray-50">
              Notification Preferences
            </button>
            <button className="w-full text-left px-4 py-2 border rounded hover:bg-gray-50 text-red-600">
              Delete Account
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage; 