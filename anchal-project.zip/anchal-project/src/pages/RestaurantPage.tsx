import React, { useState } from 'react';
import { useParams } from 'react-router-dom';

interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
}

const mockRestaurant = {
  id: '1',
  name: 'Pizza Heaven',
  image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=1000',
  cuisine: 'Italian',
  rating: 4.7,
  deliveryTime: '30-40 min',
  minOrder: 15,
  deliveryFee: 2.99,
  address: '123 Main St, New York, NY 10001',
  description: 'Authentic Italian pizzas made with fresh ingredients and traditional recipes.',
};

const mockMenuItems: MenuItem[] = [
  {
    id: '1',
    name: 'Margherita Pizza',
    description: 'Fresh tomatoes, mozzarella, basil, and olive oil',
    price: 12.99,
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=300',
    category: 'Pizza',
  },
  {
    id: '2',
    name: 'Pepperoni Pizza',
    description: 'Classic pepperoni with mozzarella and tomato sauce',
    price: 14.99,
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=300',
    category: 'Pizza',
  },
  {
    id: '3',
    name: 'Garlic Bread',
    description: 'Freshly baked bread with garlic butter and herbs',
    price: 4.99,
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=300',
    category: 'Sides',
  },
  {
    id: '4',
    name: 'Caesar Salad',
    description: 'Romaine lettuce, croutons, parmesan, and Caesar dressing',
    price: 8.99,
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=300',
    category: 'Salads',
  },
];

const categories = ['All', 'Pizza', 'Sides', 'Salads', 'Drinks'];

const RestaurantPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredItems = mockMenuItems.filter(
    (item) => selectedCategory === 'All' || item.category === selectedCategory
  );

  return (
    <div>
      {/* Restaurant Header */}
      <div className="relative h-64 bg-gray-900">
        <img
          src={mockRestaurant.image}
          alt={mockRestaurant.name}
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl font-bold mb-2">{mockRestaurant.name}</h1>
            <p className="text-lg">{mockRestaurant.cuisine}</p>
          </div>
        </div>
      </div>

      {/* Restaurant Info */}
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-semibold text-gray-900">Rating</h3>
              <div className="flex items-center mt-1">
                <svg
                  className="w-5 h-5 text-yellow-400"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                <span className="ml-1">{mockRestaurant.rating}</span>
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Delivery Time</h3>
              <p className="mt-1">{mockRestaurant.deliveryTime}</p>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Minimum Order</h3>
              <p className="mt-1">${mockRestaurant.minOrder}</p>
            </div>
          </div>
          <div className="mt-4">
            <h3 className="font-semibold text-gray-900">About</h3>
            <p className="mt-1 text-gray-600">{mockRestaurant.description}</p>
          </div>
        </div>

        {/* Menu Categories */}
        <div className="mb-8">
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <button
                key={category}
                className={`px-4 py-2 rounded-full whitespace-nowrap ${
                  selectedCategory === category
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Menu Items */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-lg shadow-md overflow-hidden flex"
            >
              <img
                src={item.image}
                alt={item.name}
                className="w-32 h-32 object-cover"
              />
              <div className="p-4 flex-1">
                <h3 className="font-semibold text-lg mb-1">{item.name}</h3>
                <p className="text-gray-600 text-sm mb-2">{item.description}</p>
                <div className="flex items-center justify-between">
                  <span className="font-semibold">${item.price.toFixed(2)}</span>
                  <button className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RestaurantPage; 