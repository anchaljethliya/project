export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  address: Address[];
  preferences: UserPreferences;
}

export interface Address {
  id: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  isDefault: boolean;
}

export interface UserPreferences {
  dietaryPreferences: string[];
  favoriteRestaurants: string[];
  safetySettings: SafetySettings;
}

export interface SafetySettings {
  enableLiveTracking: boolean;
  trustedContacts: TrustedContact[];
  preferFemaleDriver: boolean;
}

export interface TrustedContact {
  id: string;
  name: string;
  phone: string;
  email?: string;
}

export interface Restaurant {
  id: string;
  name: string;
  description: string;
  cuisine: string[];
  rating: number;
  address: Address;
  menu: MenuItem[];
  isEcoFriendly: boolean;
  deliveryFee: {
    base: number;
    perKm: number;
  };
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  dietaryInfo: string[];
  image?: string;
  isAvailable: boolean;
}

export interface Order {
  id: string;
  userId: string;
  restaurantId: string;
  items: OrderItem[];
  status: OrderStatus;
  deliveryInfo: DeliveryInfo;
  payment: PaymentInfo;
  createdAt: string;
  updatedAt: string;
}

export interface OrderItem {
  menuItemId: string;
  quantity: number;
  specialInstructions?: string;
  price: number;
}

export type OrderStatus = 
  | 'pending'
  | 'confirmed'
  | 'preparing'
  | 'ready_for_pickup'
  | 'picked_up'
  | 'in_transit'
  | 'delivered'
  | 'cancelled';

export interface DeliveryInfo {
  deliveryAgentId?: string;
  estimatedDeliveryTime?: string;
  actualDeliveryTime?: string;
  trackingLink?: string;
  distance: number;
  deliveryFee: number;
}

export interface PaymentInfo {
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  method: string;
  transactionId?: string;
} 